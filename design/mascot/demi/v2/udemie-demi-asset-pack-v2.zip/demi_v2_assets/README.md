# Udemie — Demi Asset Pack v2

This package contains the refined production-ready Demi mascot assets, derived from the approved fidelity refinement board.

## Structure
- `svg/`: editable SVG source assets
- `png/256`, `png/512`, `png/1024`: transparent PNG exports
- `previews/`: preview sheets

## Included assets
- demi-classic
- demi-happy
- demi-curious
- demi-focused
- demi-celebrating
- demi-audio-recap
- demi-highlights
- demi-sleeping
- demi-thinking
- demi-monochrome

## Notes
- Designed for Udemie Light and Dark themes
- Transparent PNGs are suitable for immediate product integration
- SVGs use native vector shapes and gradients for future editing/animation
